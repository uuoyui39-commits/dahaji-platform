# منصة الأستاذ أحمد الدهاجي — فيزياء السادس الإعدادي

**حالة المشروع: غير مكتمل.** راجع قسم «المتبقي» أدناه.

## البنية
- الواجهة: React + Vite + TypeScript + Tailwind (تُنشر على Netlify).
- الخلفية: Supabase (Auth وPostgres وStorage). المنطق الحساس يعمل داخل دوال SQL (`security definer`) وسياسات RLS.
- المساعد الذكي: Supabase Edge Function باسم `physics-assistant`. لا توجد Netlify Functions حالياً لأنها غير مطلوبة.

## التشغيل المحلي
1. `npm install`
2. انسخ `.env.example` إلى `.env` وضع `VITE_SUPABASE_URL` و`VITE_SUPABASE_ANON_KEY` (المفتاح العام فقط).
3. `npm run dev`

## إعداد Supabase
1. أنشئ مشروعاً. من SQL Editor شغّل الملفات **بالترتيب ومرة واحدة** من `supabase/migrations/`: `001` ثم `002` ثم `003` ثم `004`. (`001`–`003` غير قابلة لإعادة التشغيل؛ عند الخطأ أعد إنشاء المشروع التجريبي.)
2. Authentication ← URL Configuration: ضع رابط موقعك في Site URL وRedirect URLs.
3. أول مدير: سجّل حساباً عادياً من الموقع، ثم شغّل في SQL Editor:
   `update public.profiles set role='admin', status='approved' where email='بريدك';`
4. المساعد الذكي (يتطلب Supabase CLI): `supabase link --project-ref <ref>` ثم
   `supabase secrets set GEMINI_API_KEY=... ALLOWED_ORIGIN=https://موقعك.netlify.app`
   ثم `supabase functions deploy physics-assistant`.
   مفتاح service_role يوفره Supabase للدالة تلقائياً ولا يوضع في أي ملف.

## النشر على Netlify
ارفع المشروع إلى مستودع Git ثم Add new site ← Import from Git. الإعدادات في `netlify.toml` (أمر البناء `npm run build`، المجلد `dist`، وإعادة التوجيه لدعم React Router). عرّف في Site settings ← Environment variables: `VITE_SUPABASE_URL` و`VITE_SUPABASE_ANON_KEY`. رفع مجلد `dist` يدوياً يعمل لنشر الواجهة فقط.

## المتبقي (غير منفذ)
- إدارة الامتحانات والأسئلة والمحتوى والإعلانات والإعدادات من واجهة الإدارة، وشاشة التصحيح (دوال التصحيح موجودة في SQL).
- الصفحة الرئيسية الكاملة، لوحة الطالب، المكتبة، الملف الشخصي، استعادة كلمة المرور.
- خطة الدراسة، الملاحظات، صفحة الإشعارات، الإعلانات، التقارير.
- الاختبارات الآلية.
