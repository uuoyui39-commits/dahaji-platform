create type public.question_type as enum ('mcq','true_false','short','essay','image','math','handwritten');

create table public.exams (
  id uuid primary key default gen_random_uuid(),
  title text not null, description text, instructions text,
  starts_at timestamptz not null, ends_at timestamptz not null,
  duration_minutes int not null check (duration_minutes > 0),
  total_score numeric not null default 100 check (total_score > 0),
  status text not null default 'draft' check (status in ('draft','published','archived')),
  result_mode text not null default 'after_review' check (result_mode in ('immediate','after_review')),
  show_answers_at timestamptz,            -- null = لا تُعرض الإجابات الصحيحة أبداً
  max_attempts int not null default 1 check (max_attempts >= 1),
  shuffle_questions boolean not null default false,
  shuffle_options boolean not null default false,
  created_by uuid references public.profiles(id), created_at timestamptz not null default now(),
  check (ends_at > starts_at)
);
create table public.questions (
  id uuid primary key default gen_random_uuid(),
  exam_id uuid not null references public.exams(id) on delete cascade,
  position int not null default 0, type public.question_type not null,
  body text not null,                      -- يدعم KaTeX بين $...$
  image_path text, points numeric not null default 1 check (points >= 0),
  options jsonb                            -- [{id,text}] بدون أي إشارة للصحيح
);
-- مفاتيح الإجابة في جدول منفصل لا يقرؤه إلا المدير
create table public.question_keys (
  question_id uuid primary key references public.questions(id) on delete cascade,
  correct jsonb,                           -- mcq/true_false: "id" | short: ["قبول1","قبول2"]
  explanation text
);
create table public.attempts (
  id uuid primary key default gen_random_uuid(),
  exam_id uuid not null references public.exams(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  attempt_no int not null, started_at timestamptz not null default now(),
  deadline_at timestamptz not null, submitted_at timestamptz,
  status text not null default 'in_progress' check (status in ('in_progress','submitted','graded')),
  score numeric, released boolean not null default false,
  graded_by uuid references public.profiles(id), graded_at timestamptz,
  unique (exam_id, user_id, attempt_no)
);
create unique index one_open_attempt on public.attempts (exam_id, user_id) where status = 'in_progress';
create table public.answers (
  attempt_id uuid not null references public.attempts(id) on delete cascade,
  question_id uuid not null references public.questions(id) on delete cascade,
  answer jsonb, upload_path text, score numeric, feedback text, auto_graded boolean not null default false,
  graded_by uuid references public.profiles(id), graded_at timestamptz, saved_at timestamptz not null default now(),
  primary key (attempt_id, question_id)
);

alter table public.exams enable row level security;
alter table public.questions enable row level security;
alter table public.question_keys enable row level security;
alter table public.attempts enable row level security;
alter table public.answers enable row level security;
create policy exams_admin on public.exams for all using (public.is_admin()) with check (public.is_admin());
create policy exams_students on public.exams for select using (status = 'published' and public.is_approved());
create policy q_admin on public.questions for all using (public.is_admin()) with check (public.is_admin());
create policy k_admin on public.question_keys for all using (public.is_admin()) with check (public.is_admin());
create policy att_own on public.attempts for select using (user_id = auth.uid() or public.is_admin());
create policy ans_own on public.answers for select using (public.is_admin() or exists (select 1 from attempts t where t.id = attempt_id and t.user_id = auth.uid()));
-- لا سياسات INSERT/UPDATE للطالب: كل الكتابة عبر الدوال أدناه فقط

-- تصحيح تلقائي: اختيار/صح-خطأ/إجابة قصيرة (فقط إذا حدد المدير إجابات مقبولة). الباقي يدوي.
create function public._finalize(p_att uuid) returns void language plpgsql security definer set search_path = public as $$
declare t attempts;
begin
  select * into t from attempts where id = p_att for update;
  if t.status <> 'in_progress' then return; end if;
  update attempts set submitted_at = least(now(), t.deadline_at), status = 'submitted' where id = p_att;
  insert into answers (attempt_id, question_id, answer, score, auto_graded)
    select p_att, q.id, null, 0, true from questions q
    where q.exam_id = t.exam_id and not exists (select 1 from answers a where a.attempt_id = p_att and a.question_id = q.id);
  update answers a set auto_graded = true, graded_at = now(), score = case
      when q.type in ('mcq','true_false') then case when a.answer #>> '{}' = k.correct #>> '{}' then q.points else 0 end
      else case when exists (select 1 from jsonb_array_elements_text(k.correct) c where lower(trim(c)) = lower(trim(a.answer #>> '{}'))) then q.points else 0 end end
    from questions q join question_keys k on k.question_id = q.id
    where a.attempt_id = p_att and a.question_id = q.id and a.auto_graded = false
      and (q.type in ('mcq','true_false') or (q.type = 'short' and jsonb_typeof(k.correct) = 'array'));
  perform public._recompute(p_att);
end $$;

create function public._recompute(p_att uuid) returns void language plpgsql security definer set search_path = public as $$
declare t attempts; e exams; pending int; sm numeric; pts numeric;
begin
  select * into t from attempts where id = p_att; select * into e from exams where id = t.exam_id;
  if t.status = 'in_progress' then return; end if;
  select count(*) into pending from answers where attempt_id = p_att and score is null;
  if pending > 0 then update attempts set status = 'submitted', score = null where id = p_att; return; end if;
  select coalesce(sum(score), 0) into sm from answers where attempt_id = p_att;
  select sum(points) into pts from questions where exam_id = t.exam_id;
  update attempts set status = 'graded', score = round(sm * e.total_score / nullif(pts, 0), 2),
    released = released or e.result_mode = 'immediate' where id = p_att;
end $$;

create function public.start_attempt(p_exam uuid) returns jsonb language plpgsql security definer set search_path = public as $$
declare e exams; t attempts; n int;
begin
  if not public.is_approved() then raise exception 'account_not_approved'; end if;
  select * into e from exams where id = p_exam;
  if not found or e.status <> 'published' then raise exception 'exam_not_available'; end if;
  perform pg_advisory_xact_lock(hashtext(p_exam::text || auth.uid()::text));
  select * into t from attempts where exam_id = p_exam and user_id = auth.uid() and status = 'in_progress';
  if found then return jsonb_build_object('attempt_id', t.id); end if;   -- تحديث الصفحة يعيد نفس المحاولة
  if now() < e.starts_at then raise exception 'exam_not_started'; end if;
  if now() >= e.ends_at then raise exception 'exam_ended'; end if;
  select count(*) into n from attempts where exam_id = p_exam and user_id = auth.uid();
  if n >= e.max_attempts then raise exception 'attempts_exhausted'; end if;
  insert into attempts (exam_id, user_id, attempt_no, deadline_at)
    values (p_exam, auth.uid(), n + 1, least(now() + make_interval(mins => e.duration_minutes), e.ends_at)) returning * into t;
  return jsonb_build_object('attempt_id', t.id);
end $$;

create function public.attempt_data(p_att uuid) returns jsonb language plpgsql security definer set search_path = public as $$
declare t attempts; e exams;
begin
  select * into t from attempts where id = p_att and user_id = auth.uid();
  if not found then raise exception 'not_found'; end if;
  if t.status = 'in_progress' and now() > t.deadline_at then perform public._finalize(p_att); select * into t from attempts where id = p_att; end if;
  select * into e from exams where id = t.exam_id;
  return jsonb_build_object('server_now', now(),
    'attempt', jsonb_build_object('id', t.id, 'exam_id', t.exam_id, 'deadline_at', t.deadline_at, 'status', t.status),
    'exam', jsonb_build_object('title', e.title, 'instructions', e.instructions),
    'questions', case when t.status <> 'in_progress' then '[]'::jsonb else (
      select coalesce(jsonb_agg(jsonb_build_object('id', q.id, 'type', q.type, 'body', q.body, 'image_path', q.image_path, 'points', q.points, 'options', q.options)
        order by case when e.shuffle_questions then md5(t.id::text || q.id::text) else lpad(q.position::text, 6, '0') end), '[]'::jsonb)
      from questions q where q.exam_id = t.exam_id) end,
    'answers', (select coalesce(jsonb_object_agg(a.question_id, jsonb_build_object('answer', a.answer, 'upload_path', a.upload_path)), '{}'::jsonb)
      from answers a where a.attempt_id = p_att and t.status = 'in_progress'));
end $$;

create function public.save_answer(p_att uuid, p_q uuid, p_answer jsonb, p_upload text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare t attempts;
begin
  select * into t from attempts where id = p_att and user_id = auth.uid() for update;
  if not found then raise exception 'not_found'; end if;
  if t.status <> 'in_progress' then return jsonb_build_object('ok', false, 'reason', 'time_over'); end if;
  if now() > t.deadline_at + interval '3 seconds' then perform public._finalize(p_att); return jsonb_build_object('ok', false, 'reason', 'time_over'); end if;
  if not exists (select 1 from questions where id = p_q and exam_id = t.exam_id) then raise exception 'bad_question'; end if;
  if p_upload is not null and p_upload not like auth.uid()::text || '/' || p_att::text || '/%' then raise exception 'bad_upload'; end if;
  insert into answers (attempt_id, question_id, answer, upload_path) values (p_att, p_q, p_answer, p_upload)
    on conflict (attempt_id, question_id) do update set answer = excluded.answer, upload_path = excluded.upload_path, saved_at = now();
  return jsonb_build_object('ok', true);
end $$;

create function public.submit_attempt(p_att uuid) returns jsonb language plpgsql security definer set search_path = public as $$
declare t attempts;
begin
  select * into t from attempts where id = p_att and user_id = auth.uid() for update;   -- القفل يمنع تسليمين متزامنين
  if not found then raise exception 'not_found'; end if;
  perform public._finalize(p_att);     -- لا يفعل شيئاً إن سُلّمت المحاولة سابقاً (idempotent)
  return jsonb_build_object('ok', true);
end $$;

create function public.grade_answer(p_att uuid, p_q uuid, p_score numeric, p_feedback text) returns void
language plpgsql security definer set search_path = public as $$
declare pts numeric;
begin
  if not public.is_admin() then raise exception 'forbidden'; end if;
  select q.points into pts from questions q join attempts t on t.exam_id = q.exam_id where q.id = p_q and t.id = p_att;
  if pts is null or p_score < 0 or p_score > pts then raise exception 'bad_score'; end if;
  update answers set score = p_score, feedback = p_feedback, graded_by = auth.uid(), graded_at = now() where attempt_id = p_att and question_id = p_q;
  perform public._recompute(p_att);
  update attempts set graded_by = auth.uid(), graded_at = now() where id = p_att;
end $$;

create function public.release_result(p_att uuid, p_release boolean default true) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'forbidden'; end if;
  if p_release and exists (select 1 from attempts where id = p_att and status <> 'graded') then raise exception 'not_fully_graded'; end if;
  update attempts set released = p_release where id = p_att;
end $$;

create function public.reopen_attempt(p_att uuid, p_minutes int) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'forbidden'; end if;
  update attempts set status = 'in_progress', submitted_at = null, released = false, score = null,
    deadline_at = now() + make_interval(mins => p_minutes) where id = p_att;
end $$;

create function public.get_result(p_att uuid) returns jsonb language plpgsql security definer set search_path = public as $$
declare t attempts; e exams;
begin
  select * into t from attempts where id = p_att and user_id = auth.uid();
  if not found then raise exception 'not_found'; end if;
  if t.status = 'in_progress' and now() > t.deadline_at then perform public._finalize(p_att); select * into t from attempts where id = p_att; end if;
  select * into e from exams where id = t.exam_id;
  if not t.released then return jsonb_build_object('released', false, 'status', t.status, 'exam_title', e.title); end if;
  return jsonb_build_object('released', true, 'status', t.status, 'exam_title', e.title, 'score', t.score, 'total', e.total_score,
    'submitted_at', t.submitted_at,
    'details', case when e.show_answers_at is not null and now() >= e.show_answers_at then (
      select jsonb_agg(jsonb_build_object('body', q.body, 'points', q.points, 'answer', a.answer, 'score', a.score, 'feedback', a.feedback,
        'correct', k.correct, 'explanation', k.explanation) order by q.position)
      from questions q left join answers a on a.question_id = q.id and a.attempt_id = p_att left join question_keys k on k.question_id = q.id
      where q.exam_id = t.exam_id) else null end);
end $$;

revoke all on function public._finalize(uuid), public._recompute(uuid) from public, anon, authenticated;

-- صور الإجابات المكتوبة: مجلد المستخدم فقط، 5MB، صور فقط
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
  values ('answers', 'answers', false, 5242880, array['image/jpeg','image/png','image/webp']) on conflict do nothing;
create policy ans_up on storage.objects for insert with check (bucket_id = 'answers' and public.is_approved() and (storage.foldername(name))[1] = auth.uid()::text);
create policy ans_read on storage.objects for select using (bucket_id = 'answers' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin()));
