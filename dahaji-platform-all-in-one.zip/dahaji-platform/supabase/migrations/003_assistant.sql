create table public.chat_conversations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null default 'محادثة جديدة',
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.chat_messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.chat_conversations(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  role text not null check (role in ('user','assistant')),
  content text not null check (length(content) <= 20000),
  image_path text, created_at timestamptz not null default now()
);
create index on public.chat_messages (conversation_id, created_at);
-- سجل استخدام لحدود الاستخدام (يشمل إعادة التوليد)
create table public.ai_usage (id bigserial primary key, user_id uuid not null references public.profiles(id) on delete cascade, created_at timestamptz not null default now());
create index on public.ai_usage (user_id, created_at);

alter table public.chat_conversations enable row level security;
alter table public.chat_messages enable row level security;
alter table public.ai_usage enable row level security;
-- محادثات الطالب خاصة به فقط (حتى المدير لا يقرؤها). الكتابة تتم عبر Edge Function (service role)
create policy conv_select on public.chat_conversations for select using (user_id = auth.uid());
create policy conv_delete on public.chat_conversations for delete using (user_id = auth.uid());
create policy msg_select on public.chat_messages for select using (user_id = auth.uid());
-- ai_usage: بلا سياسات = لا وصول من العميل

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
  values ('chat-images', 'chat-images', false, 4194304, array['image/jpeg','image/png','image/webp']) on conflict do nothing;
create policy chat_img_up on storage.objects for insert with check (bucket_id = 'chat-images' and public.is_approved() and (storage.foldername(name))[1] = auth.uid()::text);
create policy chat_img_read on storage.objects for select using (bucket_id = 'chat-images' and (storage.foldername(name))[1] = auth.uid()::text);
