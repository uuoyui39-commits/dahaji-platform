create type public.user_role as enum ('student','admin');
create type public.account_status as enum ('pending','approved','suspended');
create type public.resource_type as enum ('lecture','pdf','summary','review','laws','video','link');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  email text,
  role public.user_role not null default 'student',
  status public.account_status not null default 'pending',
  created_at timestamptz not null default now()
);

create or replace function public.is_admin() returns boolean
language sql security definer stable set search_path = public as
$$ select exists (select 1 from profiles where id = auth.uid() and role = 'admin' and status = 'approved') $$;

create or replace function public.is_approved() returns boolean
language sql security definer stable set search_path = public as
$$ select exists (select 1 from profiles where id = auth.uid() and status = 'approved') $$;

-- دائماً طالب + pending مهما أُرسل من العميل
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into profiles (id, full_name, email, role, status)
  values (new.id, coalesce(nullif(trim(new.raw_user_meta_data->>'full_name'), ''), 'طالب'), new.email, 'student', 'pending');
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- منع الطالب من تغيير دوره/حالته (auth.uid() فارغ = محرر SQL/الخدمة)
create or replace function public.guard_profile_update() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and not public.is_admin() then
    new.role := old.role; new.status := old.status; new.id := old.id; new.email := old.email;
  end if;
  return new;
end $$;
create trigger guard_profile_update before update on public.profiles
  for each row execute function public.guard_profile_update();

alter table public.profiles enable row level security;
create policy "profiles_select" on public.profiles for select using (id = auth.uid() or public.is_admin());
create policy "profiles_update" on public.profiles for update using (id = auth.uid() or public.is_admin());

create table public.resources (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  type public.resource_type not null,
  category text,
  external_url text,
  storage_path text,
  is_published boolean not null default false,
  is_public boolean not null default false,
  created_at timestamptz not null default now()
);
alter table public.resources enable row level security;
create policy "res_admin" on public.resources for all using (public.is_admin()) with check (public.is_admin());
create policy "res_students" on public.resources for select using (is_published and public.is_approved());
create policy "res_public" on public.resources for select using (is_published and is_public);

create table public.favorites (
  user_id uuid not null references public.profiles(id) on delete cascade,
  resource_id uuid not null references public.resources(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, resource_id)
);
alter table public.favorites enable row level security;
create policy "fav_own" on public.favorites for all
  using (user_id = auth.uid() and public.is_approved()) with check (user_id = auth.uid() and public.is_approved());

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null, body text, is_read boolean not null default false,
  created_at timestamptz not null default now()
);
alter table public.notifications enable row level security;
create policy "notif_select" on public.notifications for select using (user_id = auth.uid());
create policy "notif_mark_read" on public.notifications for update using (user_id = auth.uid());
create policy "notif_admin" on public.notifications for all using (public.is_admin()) with check (public.is_admin());

insert into storage.buckets (id, name, public) values ('resources', 'resources', false) on conflict do nothing;
create policy "storage_admin" on storage.objects for all
  using (bucket_id = 'resources' and public.is_admin()) with check (bucket_id = 'resources' and public.is_admin());
create policy "storage_students_read" on storage.objects for select
  using (bucket_id = 'resources' and public.is_approved());

-- ترقية أول مدير يدوياً (لا يوجد تسجيل مدير من الواجهة):
-- update public.profiles set role='admin', status='approved' where email='YOUR_EMAIL';
