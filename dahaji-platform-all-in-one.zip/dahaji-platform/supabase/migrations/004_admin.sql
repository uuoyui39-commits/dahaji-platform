-- قابل لإعادة التشغيل (idempotent)
create table if not exists public.platform_settings (
  key text primary key, value jsonb not null, updated_at timestamptz not null default now()
);  -- قيم غير سرية فقط (اسم المنصة، الروابط...)
create table if not exists public.audit_logs (
  id bigserial primary key, actor_id uuid references public.profiles(id) on delete set null,
  action text not null, target_id uuid, details jsonb, created_at timestamptz not null default now()
);
create index if not exists audit_logs_created on public.audit_logs (created_at desc);
alter table public.platform_settings enable row level security;
alter table public.audit_logs enable row level security;
drop policy if exists settings_read on public.platform_settings;
drop policy if exists settings_admin on public.platform_settings;
drop policy if exists audit_admin_read on public.audit_logs;
create policy settings_read on public.platform_settings for select using (true);
create policy settings_admin on public.platform_settings for all using (public.is_admin()) with check (public.is_admin());
create policy audit_admin_read on public.audit_logs for select using (public.is_admin());  -- الكتابة عبر الدوال فقط

create or replace function public.admin_stats() returns jsonb language plpgsql security definer stable set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'forbidden'; end if;
  return jsonb_build_object(
    'accounts', (select count(*) from profiles where role = 'student'),
    'approved', (select count(*) from profiles where role = 'student' and status = 'approved'),
    'pending', (select count(*) from profiles where role = 'student' and status = 'pending'),
    'suspended', (select count(*) from profiles where role = 'student' and status = 'suspended'),
    'exams_published', (select count(*) from exams where status = 'published'),
    'exams_draft', (select count(*) from exams where status = 'draft'),
    'attempts', (select count(*) from attempts where status <> 'in_progress'),
    'attempts_7d', (select count(*) from attempts where started_at > now() - interval '7 days'),
    'resources', (select count(*) from resources));
end $$;

create or replace function public.admin_set_status(p_user uuid, p_status public.account_status) returns void
language plpgsql security definer set search_path = public as $$
declare old public.account_status;
begin
  if not public.is_admin() then raise exception 'forbidden'; end if;
  if p_user = auth.uid() then raise exception 'cannot_change_self'; end if;
  select status into old from profiles where id = p_user and role = 'student';
  if not found then raise exception 'not_found'; end if;
  update profiles set status = p_status where id = p_user;
  insert into audit_logs (actor_id, action, target_id, details) values (auth.uid(), 'set_account_status', p_user, jsonb_build_object('from', old, 'to', p_status));
  if p_status = 'approved' and old <> 'approved' then
    insert into notifications (user_id, title, body) values (p_user, 'تم اعتماد حسابك', 'يمكنك الآن الوصول إلى الامتحانات والمكتبة والمساعد الذكي.');
  end if;
end $$;
