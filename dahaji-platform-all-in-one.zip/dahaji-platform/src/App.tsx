import { Route, Routes } from 'react-router-dom'
import { Layout } from './components/Layout'
import { ProtectedRoute } from './components/ProtectedRoute'
import Home from './pages/Home'
import Pending from './pages/Pending'
import { Login, Register } from './pages/Auth'
import Exams from './pages/Exams'
import ExamTake from './pages/ExamTake'
import AdminDashboard from './pages/admin/AdminDashboard'
import AdminExams from './pages/admin/AdminExams'
import AdminQuestions from './pages/admin/AdminQuestions'
import AdminGrading from './pages/admin/AdminGrading'
import Assistant from './pages/Assistant'
import Result from './pages/Result'
import { NotFound, Suspended, Unauthorized } from './pages/Status'
export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Home />} />
        <Route path="/suspended" element={<Suspended />} />
        <Route path="/unauthorized" element={<Unauthorized />} />
        <Route element={<ProtectedRoute requireApproved={false} />}><Route path="/pending" element={<Pending />} /></Route>
        <Route path="/login" element={<Login />} /><Route path="/register" element={<Register />} />
        <Route element={<ProtectedRoute />}><Route element={<ProtectedRoute requireAdmin />}><Route path="/admin" element={<AdminDashboard />} /><Route path="/admin/exams" element={<AdminExams />} /><Route path="/admin/exams/:examId/questions" element={<AdminQuestions />} /><Route path="/admin/exams/:examId/grading" element={<AdminGrading />} /></Route>
        <Route path="/assistant" element={<Assistant />} /><Route path="/exams" element={<Exams />} /><Route path="/exams/:examId/take" element={<ExamTake />} /><Route path="/results/:attemptId" element={<Result />} /></Route>
        {/* الدفعة 2: /login /register /forgot-password /reset-password /profile */}
        {/* الدفعة 3: /dashboard /library — الدفعة 4: /admin/* */}
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  )
}
