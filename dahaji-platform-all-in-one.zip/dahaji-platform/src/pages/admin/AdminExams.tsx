import { useCallback, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../context/AuthContext'
import { Spinner } from '../../components/Spinner'

interface Ex { id: string; title: string; description: string | null; instructions: string | null; starts_at: string; ends_at: string; duration_minutes: number; total_score: number; status: 'draft' | 'published' | 'archived'; result_mode: string; show_answers_at: string | null; max_attempts: number; shuffle_questions: boolean }
const SL = { draft: 'مسودة', published: 'منشور', archived: 'مؤرشف' }
const loc = (s?: string | null) => (s ? new Date(new Date(s).getTime() - new Date(s).getTimezoneOffset() * 6e4).toISOString().slice(0, 16) : '')
const empty = { id: '', title: '', description: '', instructions: '', starts_at: '', ends_at: '', duration_minutes: 60, total_score: 100, result_mode: 'after_review', show_answers_at: '', max_attempts: 1, shuffle_questions: false }

export default function AdminExams() {
  const { session } = useAuth()
  const [list, setList] = useState<Ex[] | null>(null); const [f, setF] = useState<typeof empty | null>(null); const [err, setErr] = useState(''); const [ok, setOk] = useState('')
  const load = useCallback(async () => { const { data, error } = await supabase.from('exams').select('*').order('created_at', { ascending: false }); if (error) setErr('تعذّر تحميل الامتحانات.'); else setList(data as Ex[]) }, [])
  useEffect(() => { load() }, [load])

  const save = async () => {
    if (!f) return; setErr(''); setOk('')
    if (f.title.trim().length < 3) return setErr('اكتب عنوان الامتحان.')
    if (!f.starts_at || !f.ends_at || new Date(f.ends_at) <= new Date(f.starts_at)) return setErr('تحقق من تاريخ البداية والنهاية.')
    if (f.duration_minutes < 1 || f.total_score <= 0 || f.max_attempts < 1) return setErr('المدة والدرجة وعدد المحاولات يجب أن تكون أكبر من صفر.')
    const row = { title: f.title.trim(), description: f.description || null, instructions: f.instructions || null, starts_at: new Date(f.starts_at).toISOString(), ends_at: new Date(f.ends_at).toISOString(), duration_minutes: f.duration_minutes, total_score: f.total_score, result_mode: f.result_mode, show_answers_at: f.show_answers_at ? new Date(f.show_answers_at).toISOString() : null, max_attempts: f.max_attempts, shuffle_questions: f.shuffle_questions }
    const { error } = f.id ? await supabase.from('exams').update(row).eq('id', f.id) : await supabase.from('exams').insert({ ...row, created_by: session!.user.id })
    if (error) return setErr('فشل الحفظ.'); setOk('تم الحفظ.'); setF(null); load()
  }
  const setStatus = async (e: Ex, to: Ex['status']) => {
    setErr(''); setOk('')
    if (to === 'published') {
      const { count } = await supabase.from('questions').select('id', { count: 'exact', head: true }).eq('exam_id', e.id)
      if (!count) return setErr('أضف أسئلة قبل النشر.')
      if (!confirm('نشر الامتحان وإتاحته للطلاب حسب موعده؟')) return
    }
    const { error } = await supabase.from('exams').update({ status: to }).eq('id', e.id)
    if (error) setErr('فشل تغيير الحالة.'); else { setOk('تم تغيير الحالة.'); load() }
  }
  const del = async (e: Ex) => {
    const { count } = await supabase.from('attempts').select('id', { count: 'exact', head: true }).eq('exam_id', e.id)
    if (count) return setErr('لا يمكن حذف امتحان له مشاركات (حفاظاً على النتائج). أرشفه بدلاً من ذلك.')
    if (!confirm('حذف الامتحان وأسئلته نهائياً؟')) return
    const { error } = await supabase.from('exams').delete().eq('id', e.id); if (error) setErr('فشل الحذف.'); else load()
  }
  const set = (k: string, v: unknown) => setF(p => ({ ...p!, [k]: v }))
  if (!list) return err ? <p className="text-red-500">{err}</p> : <Spinner />
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between"><h1 className="text-2xl font-extrabold">إدارة الامتحانات</h1><button className="btn-primary" onClick={() => setF({ ...empty })}>امتحان جديد</button></div>
      {err && <p role="alert" className="text-red-500">{err}</p>}{ok && <p role="status" className="text-green-500">{ok}</p>}
      {f && <div className="glass grid gap-2 p-4 md:grid-cols-2">
        <input className="input md:col-span-2" placeholder="عنوان الامتحان" value={f.title} onChange={e => set('title', e.target.value)} />
        <textarea className="input" rows={2} placeholder="الوصف" value={f.description} onChange={e => set('description', e.target.value)} />
        <textarea className="input" rows={2} placeholder="التعليمات" value={f.instructions} onChange={e => set('instructions', e.target.value)} />
        <label className="text-sm">البداية<input type="datetime-local" className="input" value={f.starts_at} onChange={e => set('starts_at', e.target.value)} /></label>
        <label className="text-sm">النهاية<input type="datetime-local" className="input" value={f.ends_at} onChange={e => set('ends_at', e.target.value)} /></label>
        <label className="text-sm">المدة (دقيقة)<input type="number" className="input" value={f.duration_minutes} onChange={e => set('duration_minutes', +e.target.value)} /></label>
        <label className="text-sm">الدرجة النهائية<input type="number" className="input" value={f.total_score} onChange={e => set('total_score', +e.target.value)} /></label>
        <label className="text-sm">عدد المحاولات<input type="number" className="input" value={f.max_attempts} onChange={e => set('max_attempts', +e.target.value)} /></label>
        <label className="text-sm">عرض النتيجة<select className="input" value={f.result_mode} onChange={e => set('result_mode', e.target.value)}><option value="after_review">بعد المراجعة واعتمادي</option><option value="immediate">مباشرة بعد اكتمال التصحيح</option></select></label>
        <label className="text-sm md:col-span-2">إتاحة الإجابات الصحيحة بعد (اتركه فارغاً = لا تُعرض)<input type="datetime-local" className="input" value={f.show_answers_at} onChange={e => set('show_answers_at', e.target.value)} /></label>
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={f.shuffle_questions} onChange={e => set('shuffle_questions', e.target.checked)} /> ترتيب الأسئلة عشوائياً لكل طالب</label>
        <div className="flex gap-2 md:col-span-2"><button className="btn-primary" onClick={save}>حفظ</button><button className="btn-ghost" onClick={() => setF(null)}>إلغاء</button></div></div>}
      {!list.length ? <div className="glass p-8 text-center text-[var(--muted)]">لا توجد امتحانات بعد.</div> : list.map(e => (
        <div key={e.id} className="glass space-y-2 p-4"><div className="flex flex-wrap items-center justify-between gap-2"><b>{e.title}</b><span className="rounded-full border border-[var(--line)] px-3 text-sm">{SL[e.status]}</span></div>
          <p className="text-sm text-[var(--muted)]">{new Date(e.starts_at).toLocaleString('ar-IQ')} ← {new Date(e.ends_at).toLocaleString('ar-IQ')} — {e.duration_minutes} دقيقة — {e.total_score} درجة</p>
          <div className="flex flex-wrap gap-2">
            <button className="btn-ghost !py-1" onClick={() => setF({ ...e, description: e.description ?? '', instructions: e.instructions ?? '', starts_at: loc(e.starts_at), ends_at: loc(e.ends_at), show_answers_at: loc(e.show_answers_at) })}>تعديل</button>
            <Link className="btn-ghost !py-1" to={`/admin/exams/${e.id}/questions`}>الأسئلة</Link><Link className="btn-ghost !py-1" to={`/admin/exams/${e.id}/grading`}>التصحيح</Link>
            {e.status !== 'published' && <button className="btn-primary !py-1" onClick={() => setStatus(e, 'published')}>نشر</button>}
            {e.status === 'published' && <button className="btn-ghost !py-1" onClick={() => setStatus(e, 'draft')}>إخفاء (مسودة)</button>}
            {e.status !== 'archived' && <button className="btn-ghost !py-1" onClick={() => setStatus(e, 'archived')}>أرشفة</button>}
            {e.status === 'draft' && <button className="btn-ghost !py-1 text-red-400" onClick={() => del(e)}>حذف</button>}</div></div>))}
    </div>)
}
