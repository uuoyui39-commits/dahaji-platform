import { useCallback, useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { supabase } from '../../lib/supabase'
import { MathText } from '../../components/MathText'
import { Spinner } from '../../components/Spinner'
import type { QType } from '../../lib/exams'

interface Row { id: string; position: number; type: QType; body: string; points: number; image_path: string | null; options: { id: string; text: string }[] | null; key?: { correct: unknown; explanation: string | null } }
const TL: Record<QType, string> = { mcq: 'اختيار من متعدد', true_false: 'صح أو خطأ', short: 'إجابة قصيرة', essay: 'إجابة نصية', image: 'سؤال بصورة', math: 'مسألة رياضية', handwritten: 'رفع صورة الحل' }
const blank = { id: '', type: 'mcq' as QType, body: '', points: 1, position: 1, options: '', correct: '', explanation: '', image_path: '' }

export default function AdminQuestions() {
  const { examId } = useParams(); const [rows, setRows] = useState<Row[] | null>(null); const [f, setF] = useState<typeof blank | null>(null)
  const [err, setErr] = useState(''); const [ok, setOk] = useState(''); const [locked, setLocked] = useState(false)
  const load = useCallback(async () => {
    const q = await supabase.from('questions').select('*').eq('exam_id', examId!).order('position'); if (q.error) return setErr('تعذّر تحميل الأسئلة.')
    const k = await supabase.from('question_keys').select('*').in('question_id', (q.data ?? []).map(x => x.id))
    setRows((q.data as Row[]).map(r => ({ ...r, key: k.data?.find(x => x.question_id === r.id) })))
    const a = await supabase.from('attempts').select('id', { count: 'exact', head: true }).eq('exam_id', examId!); setLocked(!!a.count)
  }, [examId])
  useEffect(() => { load() }, [load])

  const edit = (r: Row) => setF({ id: r.id, type: r.type, body: r.body, points: r.points, position: r.position, image_path: r.image_path ?? '', options: (r.options ?? []).map(o => o.text).join('\n'),
    correct: Array.isArray(r.key?.correct) ? (r.key!.correct as string[]).join('\n') : String(r.key?.correct ?? ''), explanation: r.key?.explanation ?? '' })
  const upload = async (file: File) => {
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type) || file.size > 4 * 1024 * 1024) return setErr('الصورة JPG/PNG/WebP وبحجم أقصاه 4MB.')
    const path = `questions/${examId}/${crypto.randomUUID()}`
    const { error } = await supabase.storage.from('resources').upload(path, file, { contentType: file.type }); if (error) return setErr('فشل رفع الصورة.')
    setErr(''); setF(p => ({ ...p!, image_path: path }))
  }
  const save = async () => {
    if (!f) return; setErr(''); setOk('')
    if (!f.body.trim()) return setErr('اكتب نص السؤال.'); if (f.points < 0) return setErr('الدرجة غير صالحة.')
    let options: { id: string; text: string }[] | null = null; let correct: unknown = null
    if (f.type === 'mcq') {
      const t = f.options.split('\n').map(s => s.trim()).filter(Boolean); if (t.length < 2) return setErr('أدخل خيارين على الأقل (كل خيار في سطر).')
      options = t.map((text, i) => ({ id: String.fromCharCode(97 + i), text })); if (!options.some(o => o.id === f.correct)) return setErr('اختر الإجابة الصحيحة.'); correct = f.correct
    } else if (f.type === 'true_false') { if (!['true', 'false'].includes(f.correct)) return setErr('اختر الإجابة الصحيحة.'); correct = f.correct }
    else if (f.type === 'short') { const a = f.correct.split('\n').map(s => s.trim()).filter(Boolean); correct = a.length ? a : null }
    const row = { exam_id: examId!, type: f.type, body: f.body.trim(), points: f.points, position: f.position, image_path: f.image_path || null, options }
    const r = f.id ? await supabase.from('questions').update(row).eq('id', f.id).select('id').single() : await supabase.from('questions').insert(row).select('id').single()
    if (r.error) return setErr('فشل حفظ السؤال.')
    const k = await supabase.from('question_keys').upsert({ question_id: r.data.id, correct, explanation: f.explanation || null }); if (k.error) return setErr('حُفظ السؤال لكن فشل حفظ الإجابة الصحيحة.')
    setOk('تم الحفظ.'); setF(null); load()
  }
  const del = async (r: Row) => { if (locked) return setErr('لا يمكن حذف أسئلة امتحان له مشاركات.'); if (!confirm('حذف السؤال؟')) return; const { error } = await supabase.from('questions').delete().eq('id', r.id); if (error) setErr('فشل الحذف.'); else load() }
  const set = (k: string, v: unknown) => setF(p => ({ ...p!, [k]: v }))
  if (!rows) return err ? <p className="text-red-500">{err}</p> : <Spinner />
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between"><h1 className="text-2xl font-extrabold">أسئلة الامتحان</h1><div className="flex gap-2"><Link to="/admin/exams" className="btn-ghost">رجوع</Link><button className="btn-primary" onClick={() => setF({ ...blank, position: rows.length + 1 })}>سؤال جديد</button></div></div>
      {locked && <p className="text-amber-500">لهذا الامتحان مشاركات: تعديل الأسئلة قد يؤثر على التصحيح، والحذف معطّل.</p>}
      {err && <p role="alert" className="text-red-500">{err}</p>}{ok && <p role="status" className="text-green-500">{ok}</p>}
      {f && <div className="glass space-y-2 p-4">
        <div className="flex flex-wrap gap-2"><select className="input !w-auto" value={f.type} onChange={e => set('type', e.target.value)}>{(Object.keys(TL) as QType[]).map(t => <option key={t} value={t}>{TL[t]}</option>)}</select>
          <label className="text-sm">الدرجة <input type="number" className="input !inline-block !w-24" value={f.points} onChange={e => set('points', +e.target.value)} /></label>
          <label className="text-sm">الترتيب <input type="number" className="input !inline-block !w-24" value={f.position} onChange={e => set('position', +e.target.value)} /></label></div>
        <textarea className="input" rows={3} placeholder="نص السؤال (المعادلات بين $...$)" value={f.body} onChange={e => set('body', e.target.value)} />
        <div className="rounded-xl border border-dashed border-[var(--line)] p-2 text-sm"><b>معاينة:</b> <MathText text={f.body || '—'} /></div>
        <label className="block text-sm">صورة (اختياري) <input type="file" accept="image/jpeg,image/png,image/webp" onChange={e => e.target.files?.[0] && upload(e.target.files[0])} />{f.image_path && ' ✓'}</label>
        {f.type === 'mcq' && <><textarea className="input" rows={4} placeholder="الخيارات، كل خيار في سطر" value={f.options} onChange={e => set('options', e.target.value)} />
          <select className="input" value={f.correct} onChange={e => set('correct', e.target.value)}><option value="">الإجابة الصحيحة…</option>{f.options.split('\n').filter(s => s.trim()).map((t, i) => <option key={i} value={String.fromCharCode(97 + i)}>{t}</option>)}</select></>}
        {f.type === 'true_false' && <select className="input" value={f.correct} onChange={e => set('correct', e.target.value)}><option value="">الإجابة الصحيحة…</option><option value="true">صح</option><option value="false">خطأ</option></select>}
        {f.type === 'short' && <textarea className="input" rows={2} placeholder="الإجابات المقبولة للتصحيح التلقائي (كل واحدة في سطر). اتركها فارغة للتصحيح اليدوي" value={f.correct} onChange={e => set('correct', e.target.value)} />}
        <textarea className="input" rows={2} placeholder="شرح الحل (يظهر للطالب بعد موعد الإتاحة)" value={f.explanation} onChange={e => set('explanation', e.target.value)} />
        <div className="flex gap-2"><button className="btn-primary" onClick={save}>حفظ السؤال</button><button className="btn-ghost" onClick={() => setF(null)}>إلغاء</button></div></div>}
      {!rows.length ? <div className="glass p-8 text-center text-[var(--muted)]">لا توجد أسئلة بعد.</div> : rows.map(r => (
        <div key={r.id} className="glass space-y-1 p-4"><div className="text-sm text-[var(--muted)]">{r.position}. {TL[r.type]} — {r.points} درجة</div><MathText text={r.body} />
          <div className="flex gap-2 pt-1"><button className="btn-ghost !py-1" onClick={() => edit(r)}>تعديل</button><button className="btn-ghost !py-1 text-red-400" onClick={() => del(r)}>حذف</button></div></div>))}
    </div>)
}
