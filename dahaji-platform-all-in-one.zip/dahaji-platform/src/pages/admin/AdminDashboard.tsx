import { useCallback, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase, type AccountStatus } from '../../lib/supabase'
import { Spinner } from '../../components/Spinner'

interface S { id: string; full_name: string; email: string | null; status: AccountStatus; created_at: string }
const ST: Record<AccountStatus, string> = { pending: 'بانتظار الموافقة', approved: 'مقبول', suspended: 'موقوف' }
const CARDS: [string, string][] = [['accounts', 'الحسابات'], ['approved', 'المقبولون'], ['pending', 'المنتظرون'], ['suspended', 'الموقوفون'], ['exams_published', 'امتحانات منشورة'], ['exams_draft', 'امتحانات مسودة'], ['attempts', 'مشاركات مسلّمة'], ['attempts_7d', 'مشاركات آخر 7 أيام'], ['resources', 'موارد تعليمية']]

export default function AdminDashboard() {
  const [stats, setStats] = useState<Record<string, number> | null>(null)
  const [rows, setRows] = useState<S[] | null>(null)
  const [q, setQ] = useState(''); const [f, setF] = useState<'all' | AccountStatus>('all')
  const [err, setErr] = useState(''); const [ok, setOk] = useState(''); const [busy, setBusy] = useState('')

  const load = useCallback(async () => {
    setErr('')
    const [a, b] = await Promise.all([supabase.rpc('admin_stats'), supabase.from('profiles').select('id,full_name,email,status,created_at').eq('role', 'student').order('created_at', { ascending: false }).limit(500)])
    if (a.error || b.error) { setErr('تعذّر تحميل البيانات. تحقق من الاتصال.'); return }
    setStats(a.data as Record<string, number>); setRows(b.data as S[])
  }, [])
  useEffect(() => { load() }, [load])

  const setStatus = async (s: S, to: AccountStatus) => {
    const verb = to === 'approved' ? 'اعتماد' : 'إيقاف'
    if (!confirm(`${verb} حساب ${s.full_name}؟`)) return
    setBusy(s.id); setOk(''); setErr('')
    const { error } = await supabase.rpc('admin_set_status', { p_user: s.id, p_status: to })
    setBusy(''); if (error) { setErr('فشلت العملية. أعد المحاولة.'); return }
    setOk('تم تنفيذ العملية.'); load()
  }
  if (!stats || !rows) return err ? <div className="space-y-2 text-center"><p className="text-red-500">{err}</p><button className="btn-primary" onClick={load}>إعادة المحاولة</button></div> : <Spinner />
  const shown = rows.filter(r => (f === 'all' || r.status === f) && (`${r.full_name} ${r.email ?? ''}`).toLowerCase().includes(q.trim().toLowerCase()))
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between"><h1 className="text-2xl font-extrabold">لوحة الإدارة</h1><Link to="/admin/exams" className="btn-primary">إدارة الامتحانات</Link></div>
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3">{CARDS.map(([k, l]) => <div key={k} className="glass p-4"><div className="text-3xl font-extrabold">{stats[k] ?? 0}</div><div className="text-sm text-[var(--muted)]">{l}</div></div>)}</div>
      <section className="glass space-y-3 p-4"><h2 className="text-lg font-extrabold">الطلاب</h2>
        <div className="flex flex-wrap gap-2"><input className="input min-w-0 flex-1" placeholder="بحث بالاسم أو البريد" value={q} onChange={e => setQ(e.target.value)} />
          <select className="input !w-auto" value={f} onChange={e => setF(e.target.value as typeof f)} aria-label="تصفية الحالة"><option value="all">كل الحالات</option>{(Object.keys(ST) as AccountStatus[]).map(k => <option key={k} value={k}>{ST[k]}</option>)}</select></div>
        {err && <p role="alert" className="text-red-500">{err}</p>}{ok && <p role="status" className="text-green-500">{ok}</p>}
        {!shown.length ? <p className="p-4 text-center text-[var(--muted)]">لا توجد حسابات مطابقة.</p> :
          <div className="overflow-x-auto"><table className="w-full text-sm"><thead><tr className="text-start text-[var(--muted)]"><th className="p-2 text-start">الاسم</th><th className="p-2 text-start">البريد</th><th className="p-2 text-start">الحالة</th><th className="p-2 text-start">التسجيل</th><th /></tr></thead>
            <tbody>{shown.map(s => <tr key={s.id} className="border-t border-[var(--line)]"><td className="p-2">{s.full_name}</td><td className="p-2" dir="ltr">{s.email}</td><td className="p-2">{ST[s.status]}</td><td className="p-2">{new Date(s.created_at).toLocaleDateString('ar-IQ')}</td>
              <td className="space-x-2 space-x-reverse p-2 whitespace-nowrap">
                {s.status !== 'approved' && <button disabled={busy === s.id} className="btn-primary !px-3 !py-1" onClick={() => setStatus(s, 'approved')}>{s.status === 'suspended' ? 'إعادة تفعيل' : 'اعتماد'}</button>}
                {s.status !== 'suspended' && <button disabled={busy === s.id} className="btn-ghost !px-3 !py-1" onClick={() => setStatus(s, 'suspended')}>إيقاف</button>}</td></tr>)}</tbody></table></div>}
      </section>
    </div>)
}
