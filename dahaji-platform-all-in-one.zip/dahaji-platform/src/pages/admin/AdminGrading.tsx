import { useCallback, useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { supabase } from '../../lib/supabase'
import { MathText } from '../../components/MathText'
import { Spinner } from '../../components/Spinner'

interface At { id: string; status: string; score: number | null; released: boolean; submitted_at: string | null; profiles: { full_name: string } | null }
interface Qs { id: string; body: string; points: number; type: string; options: { id: string; text: string }[] | null }
interface An { question_id: string; answer: unknown; upload_path: string | null; score: number | null; feedback: string | null; auto_graded: boolean }
const SL: Record<string, string> = { submitted: 'بانتظار التصحيح', graded: 'مصحّحة' }

export default function AdminGrading() {
  const { examId } = useParams(); const [list, setList] = useState<At[] | null>(null); const [sel, setSel] = useState<At | null>(null)
  const [qs, setQs] = useState<Qs[]>([]); const [an, setAn] = useState<Record<string, An>>({}); const [urls, setUrls] = useState<Record<string, string>>({})
  const [edit, setEdit] = useState<Record<string, { score: string; feedback: string }>>({}); const [name, setName] = useState('')
  const [err, setErr] = useState(''); const [ok, setOk] = useState('')

  const loadList = useCallback(async () => {
    const { data, error } = await supabase.from('attempts').select('id,status,score,released,submitted_at,profiles(full_name)').eq('exam_id', examId!).neq('status', 'in_progress').order('submitted_at', { ascending: false })
    if (error) setErr('تعذّر تحميل المشاركات.'); else setList(data as unknown as At[])
  }, [examId])
  const open = useCallback(async (a: At) => {
    setErr(''); setOk(''); setSel(a)
    const [q, r] = await Promise.all([supabase.from('questions').select('id,body,points,type,options').eq('exam_id', examId!).order('position'), supabase.from('answers').select('*').eq('attempt_id', a.id)])
    if (q.error || r.error) return setErr('تعذّر تحميل الإجابات.')
    const m: Record<string, An> = {}; const e: typeof edit = {}; const u: Record<string, string> = {}
    for (const x of r.data as An[]) { m[x.question_id] = x; e[x.question_id] = { score: x.score == null ? '' : String(x.score), feedback: x.feedback ?? '' }
      if (x.upload_path) { const s = await supabase.storage.from('answers').createSignedUrl(x.upload_path, 3600); if (s.data) u[x.question_id] = s.data.signedUrl } }
    setQs(q.data as Qs[]); setAn(m); setEdit(e); setUrls(u)
  }, [examId])
  useEffect(() => { loadList() }, [loadList])

  const refresh = async (id: string) => { await loadList(); const { data } = await supabase.from('attempts').select('id,status,score,released,submitted_at,profiles(full_name)').eq('id', id).single(); if (data) open(data as unknown as At) }
  const grade = async (q: Qs) => {
    const e = edit[q.id]; const s = Number(e?.score); setErr(''); setOk('')
    if (e?.score === '' || Number.isNaN(s) || s < 0 || s > q.points) return setErr(`الدرجة يجب أن تكون بين 0 و${q.points}.`)
    const { error } = await supabase.rpc('grade_answer', { p_att: sel!.id, p_q: q.id, p_score: s, p_feedback: e.feedback || null })
    if (error) return setErr('فشل حفظ التصحيح.'); setOk('تم حفظ التصحيح.'); refresh(sel!.id)
  }
  const release = async (v: boolean) => {
    if (!confirm(v ? 'اعتماد النتيجة وإظهارها للطالب؟' : 'إخفاء النتيجة عن الطالب؟')) return
    const { error } = await supabase.rpc('release_result', { p_att: sel!.id, p_release: v })
    if (error) return setErr(error.message.includes('not_fully_graded') ? 'أكمل تصحيح كل الأسئلة أولاً.' : 'فشلت العملية.'); setOk('تم.'); refresh(sel!.id)
  }
  const reopen = async () => {
    const m = Number(prompt('إعادة فتح المحاولة لكم دقيقة؟', '15')); if (!m || m < 1) return
    if (!confirm('ستُحذف الدرجة الحالية ويُسمح للطالب بمتابعة الحل. متابعة؟')) return
    const { error } = await supabase.rpc('reopen_attempt', { p_att: sel!.id, p_minutes: m }); if (error) return setErr('فشلت العملية.'); setSel(null); loadList()
  }
  if (!list) return err ? <p className="text-red-500">{err}</p> : <Spinner />
  const shown = list.filter(a => (a.profiles?.full_name ?? '').includes(name.trim()))
  const show = (q: Qs, v: unknown) => { const o = q.options?.find(x => x.id === v); return o ? o.text : v === 'true' ? 'صح' : v === 'false' ? 'خطأ' : typeof v === 'string' ? v : '' }
  return (
    <div className="space-y-4"><div className="flex items-center justify-between"><h1 className="text-2xl font-extrabold">تصحيح الامتحان</h1><Link to="/admin/exams" className="btn-ghost">رجوع</Link></div>
      {err && <p role="alert" className="text-red-500">{err}</p>}{ok && <p role="status" className="text-green-500">{ok}</p>}
      <div className="grid gap-4 md:grid-cols-[18rem_1fr]">
        <aside className="glass space-y-2 p-3"><input className="input" placeholder="بحث باسم الطالب" value={name} onChange={e => setName(e.target.value)} />
          {!shown.length && <p className="p-2 text-sm text-[var(--muted)]">لا توجد مشاركات مسلّمة.</p>}
          {shown.map(a => <button key={a.id} onClick={() => open(a)} className={`w-full rounded-lg p-2 text-start ${sel?.id === a.id ? 'bg-white/10' : ''}`}><div>{a.profiles?.full_name ?? '—'}</div><div className="text-xs text-[var(--muted)]">{SL[a.status]}{a.released ? ' • معتمدة' : ''}{a.score != null ? ` • ${a.score}` : ''}</div></button>)}</aside>
        <section className="space-y-3">{!sel ? <div className="glass p-8 text-center text-[var(--muted)]">اختر مشاركة لعرضها.</div> : <>
          <div className="glass flex flex-wrap items-center justify-between gap-2 p-3"><b>{sel.profiles?.full_name} — {SL[sel.status]}{sel.score != null ? ` — ${sel.score}` : ''}</b>
            <div className="flex gap-2">{sel.status === 'graded' && !sel.released && <button className="btn-primary !py-1" onClick={() => release(true)}>اعتماد النتيجة</button>}{sel.released && <button className="btn-ghost !py-1" onClick={() => release(false)}>إخفاء النتيجة</button>}<button className="btn-ghost !py-1" onClick={reopen}>إعادة فتح</button></div></div>
          {qs.map(q => { const a = an[q.id]; return (
            <div key={q.id} className="glass space-y-2 p-4"><MathText text={q.body} />
              <div className="rounded-xl border border-[var(--line)] p-2"><span className="text-sm text-[var(--muted)]">إجابة الطالب: </span>{a?.answer ? <MathText text={show(q, a.answer)} /> : !urls[q.id] && <i>لا توجد إجابة</i>}{urls[q.id] && <a href={urls[q.id]} target="_blank" rel="noreferrer noopener"><img src={urls[q.id]} alt="حل الطالب" className="mt-2 max-h-72 rounded-lg" /></a>}</div>
              <div className="flex flex-wrap items-center gap-2"><label className="text-sm">الدرجة (من {q.points})<input type="number" step="0.25" className="input !w-24" value={edit[q.id]?.score ?? ''} onChange={e => setEdit(p => ({ ...p, [q.id]: { ...p[q.id], score: e.target.value, feedback: p[q.id]?.feedback ?? '' } }))} /></label>
                <input className="input min-w-0 flex-1" placeholder="ملاحظات للطالب" value={edit[q.id]?.feedback ?? ''} onChange={e => setEdit(p => ({ ...p, [q.id]: { score: p[q.id]?.score ?? '', feedback: e.target.value } }))} />
                <button className="btn-primary !py-1" onClick={() => grade(q)}>حفظ</button></div>{a?.auto_graded && a.score != null && <p className="text-xs text-[var(--muted)]">صُحّح تلقائياً، ويمكنك تعديله.</p>}</div>) })}</>}</section></div></div>)
}
