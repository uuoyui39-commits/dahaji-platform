import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { api, arMsg } from '../lib/exams'
import { MathText } from '../components/MathText'
import { Spinner } from '../components/Spinner'
export default function Result() {
  const { attemptId } = useParams(); const [r, setR] = useState<any>(null); const [err, setErr] = useState('')
  useEffect(() => { api.result(attemptId!).then(setR).catch(e => setErr(arMsg(e))) }, [attemptId])
  if (err) return <p className="text-red-500">{err}</p>
  if (!r) return <Spinner />
  if (!r.released) return <div className="glass mx-auto max-w-lg p-8 text-center"><h1 className="text-xl font-extrabold">{r.exam_title}</h1><p className="mt-2">تم تسليم إجابتك. النتيجة ستظهر بعد اكتمال التصحيح واعتمادها.</p></div>
  return <div className="mx-auto max-w-2xl space-y-3"><div className="glass p-6 text-center"><h1 className="text-xl font-extrabold">{r.exam_title}</h1>
    <p className="mt-2 text-3xl font-extrabold">{r.score} / {r.total}</p><p>{Math.round((r.score / r.total) * 100)}%</p></div>
    {r.details?.map((d: any, n: number) => <div key={n} className="glass space-y-1 p-4"><MathText text={d.body} /><p>درجتك: {d.score} / {d.points}</p>
      {d.feedback && <p className="text-brand-cyan">ملاحظة الأستاذ: {d.feedback}</p>}{d.explanation && <p>الحل: <MathText text={d.explanation} /></p>}</div>)}</div>
}
