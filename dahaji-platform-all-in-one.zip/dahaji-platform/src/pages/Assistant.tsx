import { useCallback, useEffect, useRef, useState } from 'react'
import { Copy, ImagePlus, Menu, Plus, RefreshCw, Send, Trash2 } from 'lucide-react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'
import { MathText } from '../components/MathText'

interface Conv { id: string; title: string }
interface Msg { id: string; role: 'user' | 'assistant'; content: string; image_path: string | null }

async function callAssistant(body: object): Promise<string> {
  const { data, error } = await supabase.functions.invoke('physics-assistant', { body })
  if (error) {
    try { const j = await (error as any).context.json(); return Promise.reject(new Error(j.error)) } catch (e) { if (e instanceof Error && e.message && !e.message.includes('context')) throw e }
    throw new Error('تعذّر الاتصال بالمساعد. تحقق من الإنترنت وأعد المحاولة.')
  }
  return data.conversation_id as string
}

export default function Assistant() {
  const { session } = useAuth(); const uid = session!.user.id
  const [convs, setConvs] = useState<Conv[]>([]); const [cid, setCid] = useState<string | null>(null); const [msgs, setMsgs] = useState<Msg[]>([])
  const [text, setText] = useState(''); const [mode, setMode] = useState<'chat' | 'solve'>('solve'); const [busy, setBusy] = useState(false)
  const [err, setErr] = useState(''); const [img, setImg] = useState<File | null>(null); const [open, setOpen] = useState(false); const [pending, setPending] = useState('')
  const end = useRef<HTMLDivElement>(null)

  const loadConvs = useCallback(async () => { const { data } = await supabase.from('chat_conversations').select('id,title').order('updated_at', { ascending: false }); setConvs((data as Conv[]) ?? []) }, [])
  const loadMsgs = useCallback(async (id: string) => { const { data, error } = await supabase.from('chat_messages').select('id,role,content,image_path').eq('conversation_id', id).order('created_at'); if (error) setErr('تعذّر تحميل المحادثة.'); else setMsgs(data as Msg[]) }, [])
  useEffect(() => { loadConvs() }, [loadConvs])
  useEffect(() => { end.current?.scrollIntoView({ behavior: 'smooth' }) }, [msgs, busy])

  const run = async (regenerate: boolean) => {
    setErr(''); setBusy(true)
    try {
      let image_path: string | null = null
      if (img && !regenerate) {
        if (!['image/jpeg', 'image/png', 'image/webp'].includes(img.type) || img.size > 4 * 1024 * 1024) throw new Error('الصورة يجب أن تكون JPG أو PNG أو WebP وبحجم أقصاه 4MB.')
        image_path = `${uid}/${Date.now()}`
        const up = await supabase.storage.from('chat-images').upload(image_path, img, { contentType: img.type }); if (up.error) throw new Error('فشل رفع الصورة.')
      }
      setPending(regenerate ? '' : text)
      const id = await callAssistant({ conversation_id: cid, message: regenerate ? undefined : text, image_path, mode, regenerate })
      setCid(id); setText(''); setImg(null); setPending(''); await Promise.all([loadMsgs(id), loadConvs()])
    } catch (e) { setErr((e as Error).message); setPending('') } finally { setBusy(false) }
  }
  const del = async (id: string) => { if (!confirm('حذف هذه المحادثة نهائياً؟')) return; const { error } = await supabase.from('chat_conversations').delete().eq('id', id); if (error) { setErr('فشل الحذف.'); return } if (id === cid) { setCid(null); setMsgs([]) } loadConvs() }
  const pick = (id: string) => { setCid(id); setOpen(false); loadMsgs(id) }

  return (
    <div className="grid gap-4 md:grid-cols-[16rem_1fr]">
      <aside className={`glass space-y-2 p-3 ${open ? '' : 'hidden'} md:block`}>
        <button className="btn-primary w-full" onClick={() => { setCid(null); setMsgs([]); setOpen(false) }}><Plus size={16} /> محادثة جديدة</button>
        {convs.length === 0 && <p className="p-2 text-sm text-[var(--muted)]">لا توجد محادثات سابقة.</p>}
        {convs.map(c => <div key={c.id} className={`flex items-center gap-1 rounded-lg p-1 ${c.id === cid ? 'bg-white/10' : ''}`}>
          <button className="flex-1 truncate text-start" onClick={() => pick(c.id)}>{c.title}</button>
          <button aria-label="حذف المحادثة" onClick={() => del(c.id)} className="p-1 text-red-400"><Trash2 size={16} /></button></div>)}
      </aside>
      <section className="glass flex min-h-[70vh] flex-col p-3">
        <button className="btn-ghost mb-2 w-fit md:hidden" onClick={() => setOpen(!open)}><Menu size={16} /> المحادثات</button>
        <div className="flex-1 space-y-3 overflow-y-auto">
          {!msgs.length && !pending && <p className="p-6 text-center text-[var(--muted)]">اسأل عن مفهوم أو ألصق مسألة، أو ارفع صورة السؤال. المساعد قد يخطئ، فراجع الحل مع أستاذك عند الشك.</p>}
          {msgs.map((m, n) => <div key={m.id} className={`max-w-[92%] rounded-2xl p-3 ${m.role === 'user' ? 'me-auto bg-brand-violet/20' : 'ms-auto border border-[var(--line)]'}`}>
            <MathText text={m.content} />{m.image_path && <p className="text-xs text-[var(--muted)]">📎 صورة مرفقة</p>}
            {m.role === 'assistant' && <div className="mt-2 flex gap-2">
              <button aria-label="نسخ" className="btn-ghost !p-1.5" onClick={() => navigator.clipboard.writeText(m.content)}><Copy size={14} /></button>
              {n === msgs.length - 1 && <button aria-label="إعادة التوليد" className="btn-ghost !p-1.5" disabled={busy} onClick={() => run(true)}><RefreshCw size={14} /></button>}</div>}</div>)}
          {pending && <div className="me-auto max-w-[92%] rounded-2xl bg-brand-violet/20 p-3"><MathText text={pending} /></div>}
          {busy && <p role="status" className="text-sm text-[var(--muted)]">المساعد يفكّر…</p>}
          <div ref={end} />
        </div>
        {err && <p role="alert" className="py-1 text-sm text-red-500">{err}</p>}
        <div className="mt-2 flex flex-wrap items-end gap-2">
          <select className="input !w-auto" value={mode} onChange={e => setMode(e.target.value as 'chat' | 'solve')} aria-label="النمط"><option value="solve">حل مسألة</option><option value="chat">شرح</option></select>
          <label className="btn-ghost cursor-pointer" title="رفع صورة"><ImagePlus size={16} />{img ? 'صورة جاهزة' : ''}<input type="file" hidden accept="image/jpeg,image/png,image/webp" onChange={e => setImg(e.target.files?.[0] ?? null)} /></label>
          <textarea className="input min-w-0 flex-1" rows={2} maxLength={4000} value={text} onChange={e => setText(e.target.value)} placeholder="اكتب سؤالك…"
            onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey && text.trim() && !busy) { e.preventDefault(); run(false) } }} />
          <button className="btn-primary" disabled={busy || !text.trim()} onClick={() => run(false)} aria-label="إرسال"><Send size={16} /></button>
        </div>
      </section>
    </div>)
}
