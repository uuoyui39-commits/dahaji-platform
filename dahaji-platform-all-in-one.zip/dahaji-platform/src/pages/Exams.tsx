import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { Spinner } from '../components/Spinner'
interface E { id: string; title: string; description: string | null; starts_at: string; ends_at: string; duration_minutes: number }
interface T { id: string; exam_id: string; status: string }
export default function Exams() {
  const [ex, setEx] = useState<E[] | null>(null); const [at, setAt] = useState<T[]>([]); const [err, setErr] = useState('')
  useEffect(() => { (async () => {
    const a = await supabase.from('exams').select('id,title,description,starts_at,ends_at,duration_minutes').order('starts_at'); if (a.error) { setErr('تعذّر تحميل الامتحانات.'); return }
    const b = await supabase.from('attempts').select('id,exam_id,status'); setEx(a.data as E[]); setAt((b.data as T[]) ?? []) })() }, [])
  if (err) return <p className="text-red-500">{err}</p>
  if (!ex) return <Spinner />
  if (!ex.length) return <div className="glass p-8 text-center">لا توجد امتحانات منشورة حالياً.</div>
  const now = Date.now(); const f = (s: string) => new Date(s).toLocaleString('ar-IQ')
  return <div className="grid gap-4 md:grid-cols-2">{ex.map(e => { const open = now >= +new Date(e.starts_at) && now < +new Date(e.ends_at); const mine = at.filter(t => t.exam_id === e.id)
    return <div key={e.id} className="glass space-y-2 p-5"><h2 className="text-lg font-extrabold">{e.title}</h2><p className="text-sm text-[var(--muted)]">{e.description}</p>
      <p className="text-sm">من {f(e.starts_at)} إلى {f(e.ends_at)} — المدة {e.duration_minutes} دقيقة</p>
      <div className="flex flex-wrap gap-2">{open && <Link className="btn-primary" to={`/exams/${e.id}/take`}>{mine.some(t => t.status === 'in_progress') ? 'متابعة الامتحان' : 'ابدأ الامتحان'}</Link>}
        {mine.filter(t => t.status !== 'in_progress').map(t => <Link key={t.id} className="btn-ghost" to={`/results/${t.id}`}>النتيجة</Link>)}</div></div> })}</div>
}
