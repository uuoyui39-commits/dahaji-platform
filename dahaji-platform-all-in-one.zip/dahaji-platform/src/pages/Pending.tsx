import { Hourglass } from 'lucide-react'
import { useAuth } from '../context/AuthContext'
export default function Pending() {
  const { profile, refresh } = useAuth()
  return (<div className="glass mx-auto max-w-lg p-8 text-center"><Hourglass className="mx-auto mb-3 text-brand-cyan" size={40} />
    <h1 className="text-2xl font-extrabold">حسابك قيد المراجعة{profile ? `، ${profile.full_name}` : ''}</h1>
    <p className="mt-2 text-[var(--muted)]">سيتم تفعيل الوصول إلى الامتحانات والمحتوى بعد موافقة الإدارة.</p>
    <button onClick={refresh} className="btn-primary mt-5">تحقق من حالة الحساب</button></div>)
}
