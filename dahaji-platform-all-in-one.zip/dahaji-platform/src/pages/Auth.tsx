import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'
const pw = z.string().min(8, 'كلمة المرور 8 أحرف على الأقل')
const L = z.object({ email: z.string().email('بريد غير صالح'), password: pw })
const R = L.extend({ full_name: z.string().trim().min(3, 'اكتب الاسم الكامل'), confirm: z.string() }).refine(v => v.password === v.confirm, { path: ['confirm'], message: 'كلمتا المرور غير متطابقتين' })
const Err = ({ m }: { m?: string }) => (m ? <p className="text-sm text-red-500">{m}</p> : null)
export function Login() {
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<z.infer<typeof L>>({ resolver: zodResolver(L) })
  const [e, setE] = useState(''); const nav = useNavigate(); const loc = useLocation() as any
  return <form className="glass mx-auto max-w-md space-y-3 p-6" onSubmit={handleSubmit(async v => { setE(''); const { error } = await supabase.auth.signInWithPassword(v); if (error) setE('البريد أو كلمة المرور غير صحيحة.'); else nav(loc.state?.from ?? '/exams', { replace: true }) })}>
    <h1 className="text-xl font-extrabold">تسجيل الدخول</h1><input className="input" type="email" placeholder="البريد الإلكتروني" {...register('email')} /><Err m={errors.email?.message} />
    <input className="input" type="password" placeholder="كلمة المرور" {...register('password')} /><Err m={errors.password?.message} /><Err m={e} />
    <button className="btn-primary w-full" disabled={isSubmitting}>دخول</button><Link to="/register" className="block text-center text-sm">ليس لديك حساب؟ سجّل الآن</Link></form>
}
export function Register() {
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<z.infer<typeof R>>({ resolver: zodResolver(R) })
  const [e, setE] = useState(''); const [ok, setOk] = useState(false)
  if (ok) return <div className="glass mx-auto max-w-md p-6 text-center">تم إنشاء الحساب. أكّد بريدك الإلكتروني إن طُلب منك، ثم انتظر موافقة الإدارة.</div>
  return <form className="glass mx-auto max-w-md space-y-3 p-6" onSubmit={handleSubmit(async v => { setE(''); const { error } = await supabase.auth.signUp({ email: v.email, password: v.password, options: { data: { full_name: v.full_name }, emailRedirectTo: location.origin + '/login' } }); if (error) setE('تعذّر إنشاء الحساب. قد يكون البريد مستخدماً.'); else setOk(true) })}>
    <h1 className="text-xl font-extrabold">حساب طالب جديد</h1>
    <input className="input" placeholder="الاسم الكامل" {...register('full_name')} /><Err m={errors.full_name?.message} />
    <input className="input" type="email" placeholder="البريد الإلكتروني" {...register('email')} /><Err m={errors.email?.message} />
    <input className="input" type="password" placeholder="كلمة المرور" {...register('password')} /><Err m={errors.password?.message} />
    <input className="input" type="password" placeholder="تأكيد كلمة المرور" {...register('confirm')} /><Err m={errors.confirm?.message} /><Err m={e} />
    <button className="btn-primary w-full" disabled={isSubmitting}>إنشاء الحساب</button></form>
}
