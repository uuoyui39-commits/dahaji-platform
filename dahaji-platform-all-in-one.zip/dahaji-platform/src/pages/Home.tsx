export default function Home() {
  return <section className="glass p-10 text-center"><h1 className="text-3xl font-extrabold md:text-5xl">منصة الأستاذ أحمد الدهاجي</h1><p className="mt-3 text-[var(--muted)]">فيزياء السادس الإعدادي — الصفحة الرئيسية الكاملة تأتي في الدفعة 3.</p></section>
}
