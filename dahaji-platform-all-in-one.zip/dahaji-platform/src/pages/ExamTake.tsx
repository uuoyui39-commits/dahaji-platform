import { useEffect, useRef, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { api, arMsg, type AttemptData, type Q } from '../lib/exams'
import { supabase } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'
import { MathText } from '../components/MathText'
import { Spinner } from '../components/Spinner'

type A = { answer?: unknown; upload?: string | null }
type St = 'local' | 'saved' | 'error'
const LBL: Record<St, string> = { local: 'محفوظ على جهازك فقط', saved: 'مؤكد من الخادم', error: 'فشل الحفظ على الخادم — سنعيد المحاولة' }
const fmt = (s: number) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`

function QImage({ path }: { path: string }) {
  const [u, setU] = useState('')
  useEffect(() => { supabase.storage.from('resources').createSignedUrl(path, 3600).then(r => setU(r.data?.signedUrl ?? '')) }, [path])
  return u ? <img src={u} alt="صورة السؤال" className="my-3 max-h-80 rounded-xl" /> : null
}

export default function ExamTake() {
  const { examId } = useParams(); const nav = useNavigate(); const { session } = useAuth()
  const [d, setD] = useState<AttemptData | null>(null); const [err, setErr] = useState('')
  const [ans, setAns] = useState<Record<string, A>>({}); const [st, setSt] = useState<Record<string, St>>({})
  const [i, setI] = useState(0); const [left, setLeft] = useState(1); const [review, setReview] = useState(false)
  const off = useRef(0); const timers = useRef<Record<string, number>>({}); const done = useRef(false)
  const aid = d?.attempt.id; const key = 'ans:' + aid

  useEffect(() => { (async () => { try {
    const { attempt_id } = await api.start(examId!); const x = await api.data(attempt_id)
    if (x.attempt.status !== 'in_progress') { nav(`/results/${attempt_id}`, { replace: true }); return }
    off.current = new Date(x.server_now).getTime() - Date.now()
    let local: Record<string, A> = {}; try { local = JSON.parse(localStorage.getItem('ans:' + attempt_id) ?? '{}') } catch {}
    const a: Record<string, A> = {}; const s: Record<string, St> = {}
    for (const k in x.answers) { a[k] = { answer: x.answers[k].answer, upload: x.answers[k].upload_path }; s[k] = 'saved' }
    for (const k in local) if (JSON.stringify(local[k]) !== JSON.stringify(a[k])) { a[k] = local[k]; s[k] = 'local' }
    setAns(a); setSt(s); setD(x)
  } catch (e) { setErr(arMsg(e)) } })() }, [examId, nav])

  useEffect(() => { if (aid) try { localStorage.setItem(key, JSON.stringify(ans)) } catch {} }, [ans, aid, key])
  useEffect(() => { if (!d) return
    const t = setInterval(() => { const r = Math.ceil((new Date(d.attempt.deadline_at).getTime() - (Date.now() + off.current)) / 1000); setLeft(r); if (r <= 0) finish() }, 1000)
    return () => clearInterval(t) })
  useEffect(() => { const on = () => retry(); window.addEventListener('online', on); return () => window.removeEventListener('online', on) })
  useEffect(() => { if (d) retry() }, [d]) // eslint-disable-line

  const save = async (q: string, a: A) => {
    try { const r = await api.save(aid!, q, a.answer ?? null, a.upload ?? null); setSt(s => ({ ...s, [q]: r.ok ? 'saved' : 'error' })); if (!r.ok) finish() }
    catch { setSt(s => ({ ...s, [q]: 'error' })) }
  }
  const retry = () => Object.keys(ans).filter(k => st[k] !== 'saved').forEach(k => save(k, ans[k]))
  const change = (q: string, a: A) => {
    setAns(p => ({ ...p, [q]: a })); setSt(s => ({ ...s, [q]: 'local' }))
    clearTimeout(timers.current[q]); timers.current[q] = window.setTimeout(() => save(q, a), 600)
  }
  const finish = async () => {
    if (done.current || !aid) return; done.current = true
    try { await Promise.all(Object.keys(ans).filter(k => st[k] !== 'saved').map(k => save(k, ans[k]))); await api.submit(aid); localStorage.removeItem(key); nav(`/results/${aid}`, { replace: true }) }
    catch (e) { done.current = false; setErr(arMsg(e)) }
  }
  const upload = async (q: string, f: File) => {
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(f.type) || f.size > 5 * 1024 * 1024) { setErr('الصورة يجب أن تكون JPG أو PNG أو WebP وبحجم أقصاه 5MB.'); return }
    const path = `${session!.user.id}/${aid}/${q}-${Date.now()}`
    const { error } = await supabase.storage.from('answers').upload(path, f, { contentType: f.type })
    if (error) { setErr('فشل رفع الصورة.'); return }
    setErr(''); change(q, { ...ans[q], upload: path })
  }

  if (err && !d) return <div className="glass mx-auto max-w-lg p-8 text-center text-red-500">{err}</div>
  if (!d) return <Spinner />
  const qs = d.questions; const q: Q = qs[i]; const a = ans[q.id] ?? {}
  const answered = (x: Q) => { const v = ans[x.id]; return !!v && (v.upload || (v.answer !== undefined && v.answer !== null && v.answer !== '')) }
  const opts = q.type === 'true_false' ? [{ id: 'true', text: 'صح' }, { id: 'false', text: 'خطأ' }] : q.options ?? []

  if (review) return (
    <div className="glass mx-auto max-w-2xl space-y-4 p-6"><h2 className="text-xl font-extrabold">مراجعة قبل التسليم</h2>
      <p>أجبت عن {qs.filter(answered).length} من {qs.length}.</p>
      <div className="flex flex-wrap gap-2">{qs.map((x, n) => <button key={x.id} onClick={() => { setI(n); setReview(false) }} className={`h-10 w-10 rounded-lg border ${answered(x) ? 'bg-brand-violet text-white' : 'border-red-400'}`}>{n + 1}</button>)}</div>
      {Object.values(st).some(v => v !== 'saved') && <p className="text-amber-500">بعض الإجابات لم تُؤكَّد من الخادم بعد؛ سنحاول حفظها عند التسليم.</p>}
      {err && <p className="text-red-500">{err}</p>}
      <div className="flex gap-2"><button className="btn-ghost" onClick={() => setReview(false)}>رجوع</button><button className="btn-primary" onClick={finish}>تسليم نهائي</button></div></div>)

  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <div className="glass sticky top-16 z-20 p-3"><div className="flex items-center justify-between"><b>{d.exam.title}</b>
        <span dir="ltr" className={`font-mono text-lg ${left < 300 ? 'text-red-500' : ''}`}>{fmt(Math.max(left, 0))}</span></div>
        <div className="mt-2 h-2 rounded bg-white/10"><div className="h-2 rounded bg-brand-grad" style={{ width: `${((i + 1) / qs.length) * 100}%` }} /></div>
        <div className="mt-1 text-sm text-[var(--muted)]">السؤال {i + 1} من {qs.length}</div></div>
      <div className="glass space-y-3 p-5">
        <div className="text-lg"><MathText text={q.body} /> <span className="text-sm text-[var(--muted)]">({q.points} درجة)</span></div>
        {q.image_path && <QImage path={q.image_path} />}
        {(q.type === 'mcq' || q.type === 'true_false') && opts.map(o => (
          <label key={o.id} className={`flex cursor-pointer items-center gap-2 rounded-xl border p-3 ${a.answer === o.id ? 'border-brand-violet' : 'border-[var(--line)]'}`}>
            <input type="radio" checked={a.answer === o.id} onChange={() => change(q.id, { ...a, answer: o.id })} /><MathText text={o.text} /></label>))}
        {q.type === 'short' && <input className="input" value={(a.answer as string) ?? ''} onChange={e => change(q.id, { ...a, answer: e.target.value })} />}
        {['essay', 'image', 'math', 'handwritten'].includes(q.type) && <textarea rows={6} className="input" placeholder={q.type === 'math' ? 'اكتب خطوات الحل (يمكن استخدام $...$ للمعادلات)' : 'اكتب إجابتك'} value={(a.answer as string) ?? ''} onChange={e => change(q.id, { ...a, answer: e.target.value })} />}
        {(q.type === 'handwritten' || q.type === 'math') && <div><input type="file" accept="image/jpeg,image/png,image/webp" onChange={e => e.target.files?.[0] && upload(q.id, e.target.files[0])} />{a.upload && <p className="text-sm text-green-500">تم رفع صورة الحل</p>}</div>}
        <p className={`text-sm ${st[q.id] === 'error' ? 'text-red-500' : 'text-[var(--muted)]'}`}>{st[q.id] ? LBL[st[q.id]] : 'لم تُجب بعد'}</p>
        {err && <p className="text-red-500">{err}</p>}
      </div>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <button className="btn-ghost" disabled={i === 0} onClick={() => setI(i - 1)}>السابق</button>
        <div className="flex max-w-full flex-wrap gap-1">{qs.map((x, n) => <button key={x.id} onClick={() => setI(n)} aria-label={`السؤال ${n + 1}`} className={`h-8 w-8 rounded text-sm ${n === i ? 'ring-2 ring-brand-cyan' : ''} ${answered(x) ? 'bg-brand-violet text-white' : 'border border-[var(--line)]'}`}>{n + 1}</button>)}</div>
        {i < qs.length - 1 ? <button className="btn-primary" onClick={() => setI(i + 1)}>التالي</button> : <button className="btn-primary" onClick={() => setReview(true)}>مراجعة وتسليم</button>}
      </div>
    </div>)
}
