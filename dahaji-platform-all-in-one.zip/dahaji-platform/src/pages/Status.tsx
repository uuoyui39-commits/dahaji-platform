export function Suspended() { return <div className="glass mx-auto max-w-lg p-8 text-center"><h1 className="text-2xl font-extrabold">الحساب موقوف</h1><p className="mt-2 text-[var(--muted)]">تواصل مع الإدارة لمعرفة السبب.</p></div> }
export function Unauthorized() { return <div className="glass mx-auto max-w-lg p-8 text-center"><h1 className="text-2xl font-extrabold">غير مصرّح لك بالدخول</h1></div> }
export function NotFound() { return <div className="glass mx-auto max-w-lg p-8 text-center"><h1 className="text-2xl font-extrabold">الصفحة غير موجودة</h1></div> }
