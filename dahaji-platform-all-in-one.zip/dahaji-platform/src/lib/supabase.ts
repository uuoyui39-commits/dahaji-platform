import { createClient } from '@supabase/supabase-js'
const url = import.meta.env.VITE_SUPABASE_URL as string | undefined
const key = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined
export const isConfigured = Boolean(url && key)
export const supabase = createClient(url ?? 'http://localhost', key ?? 'missing', {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
})
export type Role = 'student' | 'admin'
export type AccountStatus = 'pending' | 'approved' | 'suspended'
export interface Profile { id: string; full_name: string; email: string | null; role: Role; status: AccountStatus; created_at: string }
