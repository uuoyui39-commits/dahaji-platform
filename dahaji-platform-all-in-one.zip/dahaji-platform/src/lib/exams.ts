import { supabase } from './supabase'
export type QType = 'mcq' | 'true_false' | 'short' | 'essay' | 'image' | 'math' | 'handwritten'
export interface Q { id: string; type: QType; body: string; image_path: string | null; points: number; options: { id: string; text: string }[] | null }
export interface AttemptData { server_now: string; attempt: { id: string; exam_id: string; deadline_at: string; status: string }; exam: { title: string; instructions: string | null }; questions: Q[]; answers: Record<string, { answer: unknown; upload_path: string | null }> }
const ERR: Record<string, string> = { exam_not_started: 'لم يحن موعد الامتحان بعد.', exam_ended: 'انتهى وقت الامتحان.', exam_not_available: 'الامتحان غير متاح.', attempts_exhausted: 'استنفدت عدد المحاولات المسموحة.', account_not_approved: 'حسابك غير مفعّل بعد.', time_over: 'انتهى الوقت.' }
export const arMsg = (e: unknown) => { const m = (e as { message?: string })?.message ?? ''; for (const k in ERR) if (m.includes(k)) return ERR[k]; return 'حدث خطأ. تحقق من الاتصال وحاول مجدداً.' }
async function rpc<T>(fn: string, args: object) { const { data, error } = await supabase.rpc(fn, args); if (error) throw error; return data as T }
export const api = {
  start: (id: string) => rpc<{ attempt_id: string }>('start_attempt', { p_exam: id }),
  data: (id: string) => rpc<AttemptData>('attempt_data', { p_att: id }),
  save: (att: string, q: string, answer: unknown, upload: string | null) => rpc<{ ok: boolean; reason?: string }>('save_answer', { p_att: att, p_q: q, p_answer: answer, p_upload: upload }),
  submit: (id: string) => rpc<{ ok: boolean }>('submit_attempt', { p_att: id }),
  result: (id: string) => rpc<any>('get_result', { p_att: id }),
}
