import { Link } from 'react-router-dom'
import { Moon, Sun, Atom } from 'lucide-react'
import { useTheme } from '../context/ThemeContext'
import { useAuth } from '../context/AuthContext'
export function Navbar() {
  const { theme, toggle } = useTheme(); const { session, profile, signOut } = useAuth()
  return (
    <header className="sticky top-0 z-30 border-b border-[var(--line)] bg-[var(--surface)] backdrop-blur">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
        <Link to="/" className="flex items-center gap-2 font-extrabold"><Atom className="text-brand-cyan" /> الأستاذ أحمد الدهاجي</Link>
        <div className="flex items-center gap-2">
          <button onClick={toggle} className="btn-ghost !p-2" aria-label="تبديل الوضع">{theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}</button>
          {session ? (<>
            <Link to="/assistant" className="btn-ghost">المساعد</Link>
            <Link to="/exams" className="btn-ghost">الامتحانات</Link>
            <Link to={profile?.role === 'admin' ? '/admin' : '/dashboard'} className="btn-ghost">لوحتي</Link>
            <button onClick={signOut} className="btn-primary">خروج</button></>) :
            (<><Link to="/login" className="btn-ghost">دخول</Link><Link to="/register" className="btn-primary">حساب جديد</Link></>)}
        </div>
      </nav>
    </header>
  )
}
