export function Spinner() {
  return <div role="status" aria-label="جارٍ التحميل" className="grid min-h-[50vh] place-items-center"><div className="h-10 w-10 animate-spin rounded-full border-4 border-brand-violet border-t-brand-cyan" /></div>
}
