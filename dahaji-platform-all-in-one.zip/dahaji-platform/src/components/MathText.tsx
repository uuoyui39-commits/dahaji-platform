import katex from 'katex'
import 'katex/dist/katex.min.css'
/** نص عادي مع معادلات KaTeX: $inline$ و $$block$$ */
export function MathText({ text }: { text: string }) {
  return <span className="whitespace-pre-wrap">{text.split(/(\$\$[^$]+\$\$|\$[^$]+\$)/g).map((p, i) => {
    const m = p.match(/^\$\$?([^$]+)\$\$?$/)
    if (!m) return <span key={i}>{p}</span>
    return <span key={i} dir="ltr" dangerouslySetInnerHTML={{ __html: katex.renderToString(m[1], { throwOnError: false, displayMode: p.startsWith('$$') }) }} />
  })}</span>
}
