import { Navigate, Outlet, useLocation } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { Spinner } from './Spinner'

/** توجيه فقط؛ الحماية الفعلية في سياسات RLS بقاعدة البيانات. */
export function ProtectedRoute({ requireApproved = true, requireAdmin = false }: { requireApproved?: boolean; requireAdmin?: boolean }) {
  const { session, profile, loading, error } = useAuth()
  const loc = useLocation()
  if (loading) return <Spinner />
  if (!session) return <Navigate to="/login" state={{ from: loc.pathname }} replace />
  if (error || !profile) return <div className="p-8 text-center text-red-500">{error ?? 'تعذّر تحميل الحساب.'}</div>
  if (profile.status === 'suspended') return <Navigate to="/suspended" replace />
  if (requireApproved && profile.status !== 'approved') return <Navigate to="/pending" replace />
  if (requireAdmin && profile.role !== 'admin') return <Navigate to="/unauthorized" replace />
  return <Outlet />
}
