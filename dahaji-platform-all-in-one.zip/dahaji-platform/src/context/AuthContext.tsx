import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react'
import type { Session } from '@supabase/supabase-js'
import { supabase, isConfigured, type Profile } from '../lib/supabase'

interface Ctx { session: Session | null; profile: Profile | null; loading: boolean; error: string | null; refresh: () => Promise<void>; signOut: () => Promise<void> }
const AuthCtx = createContext<Ctx | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const loadProfile = useCallback(async (s: Session | null) => {
    if (!s) { setProfile(null); return }
    const { data, error } = await supabase.from('profiles').select('*').eq('id', s.user.id).single()
    if (error) { setError('تعذّر تحميل بيانات الحساب. تحقق من الاتصال وحاول مجدداً.'); setProfile(null) }
    else { setError(null); setProfile(data as Profile) }
  }, [])

  useEffect(() => {
    if (!isConfigured) { setError('لم يتم إعداد Supabase. أضف المتغيرات في ملف .env'); setLoading(false); return }
    supabase.auth.getSession().then(async ({ data }) => { setSession(data.session); await loadProfile(data.session); setLoading(false) })
      .catch(() => { setError('فشل الاتصال بالخادم.'); setLoading(false) })
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => { setSession(s); setTimeout(() => loadProfile(s), 0) })
    return () => sub.subscription.unsubscribe()
  }, [loadProfile])

  const value: Ctx = {
    session, profile, loading, error,
    refresh: () => loadProfile(session),
    signOut: async () => { await supabase.auth.signOut(); setProfile(null) },
  }
  return <AuthCtx.Provider value={value}>{children}</AuthCtx.Provider>
}
export const useAuth = () => { const c = useContext(AuthCtx); if (!c) throw new Error('useAuth خارج AuthProvider'); return c }
