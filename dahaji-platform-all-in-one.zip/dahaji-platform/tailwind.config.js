export default {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: { extend: {
    fontFamily: { sans: ['Tajawal', 'system-ui', 'sans-serif'] },
    colors: { navy: { 950: '#070b1f', 900: '#0b1230', 800: '#131c45' }, brand: { violet: '#7c5cff', cyan: '#22d3ee' } },
    backgroundImage: { 'brand-grad': 'linear-gradient(135deg,#7c5cff,#22d3ee)' }
  } }, plugins: []
}
